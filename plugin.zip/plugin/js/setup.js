var $jquery_aleksi = jQuery.noConflict();
var mode = 'plugin';
var settings;
/*
for (var setting in settings) {
    settings[setting] = chrome.storage.sync.get({setting: settings[setting]}, function(result) { return; });
}
*/
