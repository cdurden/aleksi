#!/bin/sh
env LD_LIBRARY_PATH=../src/.libs python $srcdir/AllAutomaticTests.py

