This repository contains the core parts of Voikko:

* libvoikko - The Voikko library
* voikko-fi - Finnish morphology for Voikko
* data - Shared data files used by libvoikko, Joukahainen etc.
* tests - Test data for automated tests covering the combined functionality of libvoikko and voikko-fi
* tools - Developer tools and generally useful Python libraries

The Wiki for this repository is used as the general developer Wiki for Voikko.

