/* globals jQuery, unescape, componentHandler */
(function ($) {
	'use strict';
	// pseudo-private members
	// var $ = jQuery;
	var appName = 'Copyfish'; //chrome.i18n.getMessage('appShortName');
	var appShortName = 'Copyfish';
	var $ready;
	var HTMLSTRCOPY;
	var APPCONFIG;
	var startX, startY, endX, endY;
	var startCx, startCy, endCx, endCy;
	var IS_CAPTURED = false;
	var $SELECTOR;
	var OPTIONS;
	var MAX_ZINDEX = 99999;
	var WIDGETBOTTOM = -8;
	var SELECTOR_BORDER = 2;
	var OCR_LIMIT = {
		min: {
			width: 40,
			height: 40
		},
		max: {
			width: 2600,
			height: 2600
		}
	};
	var ISPOSITIONED = false;
	var OCR_DIMENSION_ERROR = chrome.i18n.getMessage('ocrDimensionError');
	var TextOverlay = window.__TextOverlay__;

	/* 
	 *  Set to true to use a JPEG image. Default is PNG
	 *  JPEG_QUALITY ranges from 0.1 to 1 and is valid only if USE_JPEG is true
	 */
	var USE_JPEG = false;
	var JPEG_QUALITY = 0.6;


	/*Utility functions*/
	var logError = function (msg, err) {
		err = err || '';
		msg = msg || 'An error occurred.';
		//console.error('Extension ' + appShortName + ': ' + msg, err);
	};

	var _searchOCRLanguageList = function (lang) {
		var result = '';
		$.each(APPCONFIG.ocr_languages, function (i, v) {
			if (v.lang === lang) {
				result = v;
				return false;
			}
		});
		return result;
	};

	var _getLanguage = function (type, lang) {
		// var langList = APPCONFIG[type === 'OCR' ? 'ocr_languages' : 'yandex_languages'];
		var res = '';
		lang = (lang || 'en').toLowerCase();
		if (type === 'OCR') {
			res = (_searchOCRLanguageList(lang) || {}).name;
		} else {
			$.each(APPCONFIG.yandex_languages, function (k, v) {
				if (lang in v) {
					res = v[lang];
					return false;
				}
			});
		}
		return res;
	};

	var _setLanguageOnUI = function () {
		var ocrLang = _getLanguage('OCR', OPTIONS.visualCopyOCRLang);
		var translateLang = _getLanguage('translate', OPTIONS.visualCopyTranslateLang);
		$('.ocrext-label.ocrext-message span')
			.text('(' + ocrLang + ')')
			.attr({
				title: ocrLang
			});
		$('.ocrext-label.ocrext-translated span')
			.text('(' + translateLang + ')')
			.attr({
				title: translateLang
			});

		var ocrLangDir = _getLanguageDirection(ocrLang);
		$('.ocrext-result').attr('dir', ocrLangDir);
		var translateLangDir = _getLanguageDirection(translateLang);
		$('.ocrext-ocr-translated').attr('dir', translateLangDir);
	};

	var _getLanguageDirection = function (lang) {
		var rtlLanguages = ['arabic', 'arabian'];
		return rtlLanguages.indexOf(lang.toLowerCase()) === -1 ? "ltr" : "rtl";
	};

	var _setOCRFontSize = function () {
		$('.ocrext-ocr-message,.ocrext-ocr-translated')
			.removeClass(function (i, className) {
				var classes = className.match(/ocrext-font-\d\dpx/ig);
				return classes && classes.length ? classes.join(' ') : '';
			})
			.addClass('ocrext-font-' + OPTIONS.visualCopyOCRFontSize);
	};

	var _setZIndex = function () {
		/*
		 * Google Translate - 1201 Perapera - 7777 GDict - 99997 Transover - 2147483647
		 */
		if (OPTIONS.visualCopySupportDicts) {
			$('.ocrext-wrapper').css('zIndex', 1200);
		} else {
			$('.ocrext-wrapper').css('zIndex', MAX_ZINDEX);
		}
	};

	var _isImageParseError = function (data) {
		return data && data.ParsedResults && data.ParsedResults.length && data.ParsedResults[0].FileParseExitCode === -10;
	};

	var _drawQuickSelectButtons = function () {
		var $btnContainer = $('.ocrext-quickselect-btn-container');
		var $btn;
		var ocrLang;
		$btnContainer.empty();
		$.each(OPTIONS.visualCopyQuickSelectLangs, function (i, language) {
			if (language === 'none') {
				return true;
			}
			ocrLang = _searchOCRLanguageList(language);
			$btn = $([
				'<button class="ocrext-element ocrext-ocr-quickselect ocrext-btn mdl-button',
				'mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent"></button>'
			].join(' '));
			$btn.attr({
				'data-lang': ocrLang.lang,
				'title': ocrLang.name
			}).text(ocrLang.short);

			if (OPTIONS.visualCopyOCRLang === ocrLang.lang) {
				$btn.addClass('selected');
			}
			$btnContainer.append($btn);
			// upgrade button to mdl-button
			componentHandler.upgradeElement($btn.get(0));
		});
	};

	// Background mask
	var Mask = (function () {
		var $body;
		var $MASK;
		var maskString = [
			'<div class="ocrext-element ocrext-mask">',
			//'<p class="ocrext-element">Please select text to grab.</p>',
			'<div class="ocrext-overlay-corner ocrext-corner-tl"></div>',
			'<div class="ocrext-overlay-corner ocrext-corner-tr"></div>',
			'<div class="ocrext-overlay-corner ocrext-corner-br"></div>',
			'<div class="ocrext-overlay-corner ocrext-corner-bl"></div>',
			'</div>'
		].join('');

		var tl;
		var tr;
		var bl;
		var br;

		return {
			addToBody: function () {
				$body = $('body');
				if (!$MASK && !$body.find('.ocrext-mask').length) {
					$MASK = $(maskString)
						.css({
							left: 0,
							top: 0,
							width: '100%',
							height: '100%',
							zIndex: MAX_ZINDEX - 2,
							display: 'none'
						});
					$MASK.appendTo($body);

					tl = $('.ocrext-corner-tl');
					tr = $('.ocrext-corner-tr');
					br = $('.ocrext-corner-br');
					bl = $('.ocrext-corner-bl');

					this.resetPosition();
				}
				$MASK.width($(document).width());
				$MASK.height($(document).width());
				if (['absolute', 'relative', 'fixed'].indexOf($('body').css('position')) >= 0) {
					$MASK.css('position', 'fixed');
				}
				return this;
			},

			width: function (w) {
				if (w === undefined) {
					return $MASK.width();
				}
				$MASK.width(w);
			},

			height: function (h) {
				if (h === undefined) {
					return $MASK.height();
				}
				$MASK.height(h);
			},

			show: function () {
				this.resetPosition();
				$MASK.show();
				return this;
			},

			hide: function () {
				$MASK.hide();
				return this;
			},

			remove: function () {
				$MASK.remove();
				$MASK = null;
			},

			resetPosition: function () {
				var width = $(document).width();
				var height = $(document).height();
				tl.css({
					top: 0,
					left: 0,
					width: width / 2,
					height: height / 2
				});
				tr.css({
					top: 0,
					left: width / 2,
					width: width / 2,
					height: height / 2
				});
				bl.css({
					top: height / 2,
					left: 0,
					width: width / 2,
					height: height / 2
				});
				br.css({
					top: height / 2,
					left: width / 2,
					width: width / 2,
					height: height / 2
				});
			},

			reposition: function (pos) {
				var width = $(document).width();
				var height = $(document).height();

				tl.css({
					left: 0,
					top: 0,
					width: pos.tr[0],
					height: pos.tl[1]
				});

				tr.css({
					left: pos.tr[0],
					top: 0,
					width: (width - pos.tr[0]),
					height: pos.br[1]
				});

				br.css({
					left: pos.bl[0],
					top: pos.bl[1],
					width: (width - pos.bl[0]),
					height: (height - pos.bl[1])
				});

				bl.css({
					left: 0,
					top: pos.tl[1],
					width: pos.tl[0],
					height: (height - pos.tl[1])
				});
			}
		};
	}());

	/*
	 * Mutates global state by setting the OPTIONS value
	 */
    function setContextImgData(dataURI) {
        var imgData;
        if (typeof dataURI != 'undefined') {
            if (dataURI.split(',')[0].indexOf('base64') >= 0) {
                imgData = dataURI.split(',')[1];
            } else {
                imgData = unescape(dataURI.split(',')[1]);
            }
        }
		var $canOrig = $('#ocrext-canOrig');
        $carOrig.data({'contextImgData': imgData});
    }
    function imgSrcToDataURL(src, callback, outputFormat) {
        var x = new XMLHttpRequest();
        x.responseType = 'blob';
        x.open('get', src);
        x.onload = function() {
            var fileReader = new FileReader();
            fileReader.onloadend = function() {
                // fileReader.result is a data-URL (string)
                callback(fileReader.result);
                //window.open(fileReader.result);
            };
            // x.response is a Blob object
            fileReader.readAsDataURL(x.response);
        };
        x.send();
    }
	function getOptions() {
		var $optsDfd = $.Deferred();
		var theseOptions = {
			visualCopyOCRLang: '',
			visualCopyTranslateLang: '',
			// visualCopyAutoProcess: '',
			visualCopyAutoTranslate: '',
			visualCopyOCRFontSize: '',
			visualCopySupportDicts: '',
			visualCopyQuickSelectLangs: [],
			visualCopyTextOverlay: '',
			openGrabbingScreenHotkey: 0,
			closePanelHotkey: 0,
			copyTextHotkey: 0
		};
		chrome.storage.sync.get(theseOptions, function (opts) {
			OPTIONS = opts;
			// set the global options here
			$optsDfd.resolve();
		});

		return $optsDfd;
	}

	/*
	 * Mutates global state by setting the OPTIONS value
	 */
	function setOptions(opts) {
		var $optsDfd = $.Deferred();
		chrome.storage.sync.set(opts, function () {
			$.extend(OPTIONS, opts);
			// set the global options here
			$optsDfd.resolve();
		});
		return $optsDfd;
	}

	/*
	 * Loads the config, HTML and options before activating the widget
	 */
	function _bootStrapResources() {
		var $dfd = $.Deferred();

		$.when(
				$.get(chrome.extension.getURL('Copyfish/config/config.json')),
				$.get(chrome.extension.getURL('Copyfish/dialog.html')),
				getOptions()
			)
			.done(function (config, htmlStr) {
				HTMLSTRCOPY = htmlStr[0];
				// Note: it seems like with jQuery 3+,  $.get (ajax) directly returns a json object if you're loading a json file
				OCRTranslator.APPCONFIG = APPCONFIG = typeof config[0] === 'string' ? JSON.parse(config[0]) : config[0];
				$dfd.resolve(APPCONFIG, HTMLSTRCOPY);
			})
			.fail(function (err) {
				$dfd.reject();
				logError('Failed to initialize', err);
			});
		return $dfd;
	}

	/*
	 * Converts dataURI to a blob instance
	 */
	function dataURItoBlob(dataURI) {
		// convert base64/URLEncoded data component to raw binary data held in a string
		var byteString;
		if (dataURI.split(',')[0].indexOf('base64') >= 0) {
			byteString = atob(dataURI.split(',')[1]);
		} else {
			byteString = unescape(dataURI.split(',')[1]);

		}

		// separate out the mime component
		var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];

		// write the bytes of the string to a typed array
		var ia = new Uint8Array(byteString.length);
		for (var i = 0; i < byteString.length; i++) {
			ia[i] = byteString.charCodeAt(i);
		}

		return new Blob([ia], {
			type: mimeString
		});
	}

	/*depends on the global variables startCx,startCy,endCx,endCy
	 * will not work if layout changes in between calls, but there is no way to detect this.
	 * is asynchronous, returns a promise
	 */
	function _captureImageOntoCanvas() {
        //alert("_captureImageOntoCanvas()");
		var $canOrig = $('#ocrext-canOrig'),
			$can = $('#ocrext-can'),
			$dialog = $('body').find('.ocrext-wrapper');
		var $captureComplete = $.Deferred();
		// capture the current tab using the background page. On success it returns 
		// dataURL and zoom of the captured image
		getOptions().done(function () {
			_setLanguageOnUI();
			_setOCRFontSize();
			_drawQuickSelectButtons();
			setTimeout(function () {
				chrome.runtime.sendMessage({
					evt: 'capture-screen'
				}, function (response) {
					var $imageLoadDfd = $.Deferred();
					var img = new Image();

					img.onload = function () {
						$imageLoadDfd.resolve();
					};

					img.src = response.dataURL;
					$imageLoadDfd
						.done(function () {
                            //alert("$imageLoadDfd.done callback");
							// the screencapture is messed up when pixel density changes; compare the window width
							// and image width to determine if it needs to be fixed
							// also, this fix problem with page zoom
							var dpf = window.innerWidth / img.width;
							var scaleFactor = 1 / dpf,
								sx = Math.min(startCx, endCx) * scaleFactor,
								sy = Math.min(startCy, endCy) * scaleFactor,
								width = Math.abs(endCx - startCx),
								height = Math.abs(endCy - startCy),
								scaledWidth = width * scaleFactor,
								scaledHeight = height * scaleFactor;

                            //alert(scaledWidth);
                            //alert(scaledHeight);

							$canOrig.attr({
								width: scaledWidth,
								height: scaledHeight
							});
                            //alert($canOrig.width());
                            //alert($canOrig.height());

							$can.attr({
								width: width,
								height: height
							});

							var ctxOrig = $canOrig.get(0).getContext('2d');
							ctxOrig.drawImage(img, sx, sy, scaledWidth, scaledHeight, 0, 0, scaledWidth, scaledHeight);

							var ctx = $can.get(0).getContext('2d');
							ctx.drawImage(img, sx, sy, scaledWidth, scaledHeight, 0, 0, width, height); // Or at whatever offset you like
							$dialog.css({
								opacity: 1,
								bottom: WIDGETBOTTOM
							});
							$captureComplete.resolve();
						});
				});
			}, 150);
		});

		return $captureComplete;
	}

	/*
	 * Returns the ID of the most responsive server
	 */
	function _getOCRServer() {
		var $dfd = $.Deferred();
		chrome.runtime.sendMessage({
			evt: 'get-best-server'
		}, function (response) {
			$dfd.resolve(response.server.id);
		});
		return $dfd;
	}
    function mouse_event_over_element(evt, elem) {
      var o= elem.offset();
      var w= elem.width();
      var h= elem.height();
      return evt.pageX >= o.left && evt.pageX <= o.left + w && evt.pageY >= o.top && evt.pageY <= o.top + h;
    }

	/*
	 * Handles the AJAX POST calls to OCR API.
	 * Failover logic happens here!
	 */
	function _postToOCR($ocrPromise, postData, attempt) {
        //alert("posting data to OCR");
		var formData = new FormData();
		formData.append('language', postData.language);
		formData.append('file', postData.blob, postData.fileName);
		if (OPTIONS.visualCopyTextOverlay) {
			formData.append('isOverlayRequired', true);
		}
		_getOCRServer().done(function (serverId) {
			var startTime;
			var serverList = APPCONFIG.ocr_api_list;
			var maxAttempts = serverList.length;
			var ocrAPIInfo = $.grep(serverList, function (el) {
				return el.id === serverId;
			})[0];
			formData.append('apikey', ocrAPIInfo.ocr_api_key);
			attempt += 1;
			startTime = Date.now();
			$.ajax({
				url: ocrAPIInfo.ocr_api_url,
				data: formData,
				dataType: 'json',
				cache: false,
				contentType: false,
				processData: false,
				timeout: APPCONFIG.ocr_timeout,
				type: 'POST',
				success: function (data) {
					var result;
					data = data || {};
					// retry if any error condition is met and if any servers are still available
					if ((typeof data === 'string' ||
							// OCRExitCode = -10 corresponds to a parse error due to malformed/blurry image. Not the server's fault
							data.IsErroredOnProcessing ||
							data.OCRExitCode !== 1) && !_isImageParseError(data) &&
						attempt < maxAttempts) {
						// sometimes an error string is returned
						chrome.runtime.sendMessage({
							evt: 'set-server-responsetime',
							serverId: ocrAPIInfo.id,
							serverResponseTime: -1
						}, function () {
							OCRTranslator.setStatus('progress',
								chrome.i18n.getMessage('ocrProgressStatusStillWorking'), true);
							formData = null;
							_postToOCR($ocrPromise, postData, attempt);
						});
						return false;
					}
					if (typeof data === 'string') {
						$ocrPromise.reject({
							type: 'OCR',
							stat: 'OCR conversion failed',
							message: data,
							details: data,
							code: data
						});
					} else if (data.IsErroredOnProcessing) {
						$ocrPromise.reject({
							type: 'OCR',
							stat: 'OCR conversion failed',
							message: data.ErrorMessage,
							details: data.ErrorDetails,
							code: data.OCRExitCode
						});
					} else if (data.OCRExitCode === 1) {

						chrome.runtime.sendMessage({
							evt: 'set-server-responsetime',
							serverId: ocrAPIInfo.id,
							serverResponseTime: (Date.now() - startTime) / 1000
						}, function () {});
						$ocrPromise.resolve(data.ParsedResults[0].ParsedText, data.ParsedResults[0].TextOverlay);

					} else {
						result = data.ParsedResults[0];
						$ocrPromise.reject({
							type: 'OCR',
							stat: 'OCR conversion failed',
							message: result.ErrorMessage,
							details: result.ErrorDetails,
							code: result.FileParseExitCode
						});
					}
				},
				error: function (x, t) {
					var errData;
					var stat;
					if (attempt < maxAttempts) {
						chrome.runtime.sendMessage({
							evt: 'set-server-responsetime',
							serverId: ocrAPIInfo.id,
							serverResponseTime: -1
						}, function () {
							OCRTranslator.setStatus('progress',
								chrome.i18n.getMessage('ocrProgressStatusStillWorking'), true);
							formData = null;
							_postToOCR($ocrPromise, postData, attempt);
						});
						return false;
					}
					try {
						errData = JSON.parse(x.responseText);
					} catch (e) {
						errData = '';
					}
					if (t === 'timeout') {
						stat = 'OCR request timed out';
					} else if (x.status === 404) {
						stat = 'OCR service is currently unavailable';
					} else {
						stat = 'An error occurred during OCR';
					}
					$ocrPromise.reject({
						type: 'OCR',
						stat: stat,
						message: stat,
						details: null,
						code: null,
						data: errData
					});
				}
			});
		});
	}

	/*
	 * Responsible for:
	 * 1. Rolling up the canvas data into a form object along with API key and language
	 * 2. POST to OCR API
	 * 3. Handle response from OCR API and POST to Yandex translate
	 * 4. AJAX error handling anywhere in the pipeline
	 *
	 */
	function _processOCRTranslate(e) {
		// var data = new FormData();
		var dataURI;
		var ocrPostData;
		var $ocr = $.Deferred();
		var $process = $.Deferred();
		var $canOrig = $('#ocrext-canOrig');
		var dims = {
			//width: $canOrig.width(),
			//height: $canOrig.height()
			width: $canOrig.get(0).width,
			height: $canOrig.get(0).height
		};

		// read options before every AJAX call, will ensure that any changes
		// in settings are transferred to existing sessions as well
		getOptions().done(function () {
            //alert("getOptions().done callback");
			_setOCRFontSize();
			OCRTranslator.resetOverlayInformation();
			$process
				.done(function (txt, fromOCR) {
					if (txt === 'no-translate') {
						$('.ocrext-ocr-message').addClass('ocrext-preserve-whitespace expanded');
						$('.ocrext-grid-translated').hide();
						$('.ocrext-ocr-translated').text("");
						$('.ocrext-ocr-retranslate').hide();
					} else {
						$('.ocrext-ocr-message').removeClass('ocrext-preserve-whitespace expanded');
						$('.ocrext-grid-translated').show();
						$('.ocrext-ocr-retranslate').show();
						$('.ocrext-ocr-translated')
							.text(txt)
							.show();
					}

					$('.ocrext-btn').removeClass('disabled');
					OCRTranslator.setStatus('success',
						fromOCR ? chrome.i18n.getMessage('ocrSuccessStatus') : chrome.i18n.getMessage('translationSuccessStatus'));
					OCRTranslator.enableContent();
				})
				.fail(function (err) {
					// All API failure handling is done here, the AJAX callbacks simply relay
					// necessary data to this callback
					$('.ocrext-btn').removeClass('disabled');
					OCRTranslator.setStatus('error', err.stat);

					// per spec, display OCR error messages inside OCR text field
					if (err.type === 'OCR') {
						$('.ocrext-ocr-message').val(err.message);
					}
					$('.ocrext-ocr-translated').text('N/A');
					OCRTranslator.enableContent();
					//console.error('Visual Copy Exception', err);
				})
				.always(function () {
					// dereference expensive objects, just in case
					// everything terminates with $process, single point of extry/exit
					dataURI = null;
					ocrPostData = null;
					$canOrig = null;
					$ocr = null;
				});

            //alert("registering $ocr.done");
			$ocr
				.done(function (text, overlayInfo) {
					$('.ocrext-ocr-message')
						.val(text);
                    //pass ocrEvent with captured text to aleksi
                    var elmt = $(e.target);
                    /*
                    var img = elmt.find("img").first();
                    if (img.length == 0) {
                        img = elmt.parents("img").first();
                    }
                    var imgSrc = img.first().attr("src");
                    */
                    var imgSrc;
                    $('img').each(function() {
                      if (mouse_event_over_element(e, $(this))) {
                        // $(this).click(); // trigger a jQuery click() handler
                        // quickDelegate(e, this); // not in IE8
                        // this.click(); // maybe not in Mozilla pre-HTML5
                        imgSrc = $(this).attr("src");
                        //imgDataURL = imgSrcToDataURL(imgSrc, setContextImgData);
                        return false;
                      }
                    });
                    //var imgDataURL = imgSrcToDataURL(imgSrc, setContextImgData);
                    window.postMessage({ type: "FROM_PAGE", text: "ocrEvent", event: JSON.parse(JSON.stringify(e)), 'imgSrc': imgSrc }, "*");
                    //reset so that mousedown initiates recapture
                    IS_CAPTURED = false;
					// dataURI should be visible as it is encapsulated within _processOCRTranslate
					// the mad-world of async programming
					// OCRTranslator.textOverlay.setOverlayInformation(overlayInfo, dataURI);
					OCRTranslator.setOverlayInformation(overlayInfo, dataURI);
					if (OPTIONS.visualCopyTextOverlay) {
						OCRTranslator.showOverlay();
					}


					if (!OPTIONS.visualCopyAutoTranslate) {
						$process.resolve('no-translate', true);
						return true;
					}
					OCRTranslator.setStatus('progress',
						chrome.i18n.getMessage('translationProgressStatus'), true);
					$.ajax({
						url: APPCONFIG.yandex_api_url,
						data: {
							key: APPCONFIG.yandex_api_key,
							lang: OPTIONS.visualCopyTranslateLang,
							text: text
						},
						timeout: APPCONFIG.yandex_timeout,
						type: 'GET',
						success: function (data) {
							if (data.code === 200) {
								$process.resolve(data.text);
							}
						},
						error: function (x, t) {
							var errData;
							try {
								errData = JSON.parse(x.responseText);
							} catch (e) {
								errData = {};
							}
							$process.reject({
								type: 'translate',
								stat: t === 'timeout' ? 'Translation request timed out' : 'An error occurred during translation',
								message: errData.message,
								details: null,
								code: errData.code
							});
						}
					});
				})
				.fail(function (err) {
					//  receive error and relay it to $process
					$process.reject(err);
				});

			if (
				(dims.width < OCR_LIMIT.min.width && dims.height < OCR_LIMIT.min.height) ||
				(dims.width > OCR_LIMIT.max.width && dims.height > OCR_LIMIT.max.height)
			) {
                //alert("dimension error");
                //alert(dims.width);
                //alert(dims.height);
				$ocr.reject({
					type: 'OCR',
					stat: 'OCR conversion failed',
					message: OCR_DIMENSION_ERROR,
					details: null,
					code: null
				});
                IS_CAPTURED = false;
				return false;
			}

			// Disable widget, show spinner
			OCRTranslator.disableContent();
			OCRTranslator.setStatus('progress',
				chrome.i18n.getMessage('ocrProgressStatus'), true);

			// POST to OCR.
			ocrPostData = {};
			ocrPostData.language = OPTIONS.visualCopyOCRLang;
			if (USE_JPEG) {
				dataURI = $canOrig.get(0).toDataURL('image/jpeg', JPEG_QUALITY);
				ocrPostData.blob = dataURItoBlob(dataURI);
				ocrPostData.fileName = 'ocr-file.jpg';
			} else {
				dataURI = $canOrig.get(0).toDataURL();
				ocrPostData.blob = dataURItoBlob(dataURI);
				ocrPostData.fileName = 'ocr-file.png';
			}
			_postToOCR($ocr, ocrPostData, 0);

			/*
			 * $process::done can be called only if OCR and translation succeed
			 * $process::fail can be called if either OCR or translation fails
			 */

		});
	}

	/*Utility functions - end*/


	/* Event handlers*/
	/*
	 * Mouse move event handler. Attached on mousedown and removed on mouseup
	 */
	function onOCRMouseMove(e) {
		var l, t, w, h;
		if (ISPOSITIONED) {
			endX = e.pageX - $('body').scrollLeft();
			endY = e.pageY - $('body').scrollTop();
			$SELECTOR.css({
				'position': 'fixed'
			});
		} else {
			endX = e.pageX;
			endY = e.pageY;
			$SELECTOR.css({
				'position': 'absolute'
			});
		}

		l = Math.min(startX, endX);
		t = Math.min(startY, endY);
		w = Math.abs(endX - startX);
		h = Math.abs(endY - startY);

		$SELECTOR.css({
			left: l,
			top: t,
			width: w,
			height: h
		});

		Mask.reposition({
			tl: [l + SELECTOR_BORDER, t + SELECTOR_BORDER],
			tr: [l + w + SELECTOR_BORDER, t + SELECTOR_BORDER],
			bl: [l + SELECTOR_BORDER, t + h + SELECTOR_BORDER],
			br: [l + w + SELECTOR_BORDER, t + h + SELECTOR_BORDER]
		});
	}

	/*
	 * mousedown event handler
	 * once mousedown occurs, selection starts. Captures the initial coords and adds the selector
	 * rectangle onto the page. 
	 * Adds the mousemove and mouseup events
	 */
    // Modification: The callback is called with the mouseup event when the image has been captured to the canvas.
	function onOCRMouseDown(e, capture_callback, click_callback) {
		if (!IS_CAPTURED) {
			IS_CAPTURED = true;
		} else {
			return true;
		}
		var $body = $('body');
		$('.ocrext-mask p.ocrext-element').css('transform', 'scale(0,0)');
		$SELECTOR = $('<div class="ocrext-selector"></div>');
		$SELECTOR.appendTo($body);
		if (ISPOSITIONED) {
			startX = e.pageX - $body.scrollLeft();
			startY = e.pageY - $body.scrollTop();
			$SELECTOR.css({
				'position': 'fixed'
			});
		} else {
			startX = e.pageX;
			startY = e.pageY;
			$SELECTOR.css({
				'position': 'absolute'
			});
		}
		startCx = e.clientX;
		startCy = e.clientY;


		$SELECTOR.css({
			left: 0,
			top: 0,
			width: 0,
			height: 0,
			zIndex: MAX_ZINDEX - 1
		});

		$body.on('mousemove', onOCRMouseMove);

		// we need the closure here. `.one` would automagically remove the listener when done
		$body.one('mouseup', function (evt) {
			var $dialog;
			endCx = evt.clientX;
			endCy = evt.clientY;

			// turn off the mousemove event, we no longer need it
			$body.off('mousemove', onOCRMouseMove);

			// manipulate DOM to remove temporary cruft
			$body.removeClass('ocrext-ch');
			$SELECTOR.remove();
			//Mask.hide();
			// show the widget
			_setZIndex();
			$dialog = $body.find('.ocrext-wrapper');
			$dialog
				.css({
					// zIndex: MAX_ZINDEX,
					// opacity: 0,
					bottom: -$dialog.height()
				});
				//.show();

            var dx = Math.abs(endCx-startCx),
                dy = Math.abs(endCy-startCy);
            if (dx < 20 && dy < 20) {
                click_callback(evt);
            } else {
    			// initiate image capture 
    			_captureImageOntoCanvas().done(function () {
                    capture_callback(evt);
                    //alert("_processOCRTranslate(evt);");
    			});
            }
		});
	}

	/*
	 * Redo OCR button click handler
	 * Use current viewport coords to capture, process and translate screen
	 * There is no separate button to re-submit captured image, so onOCRRedo can be reused for that
	 */
	function onOCRRedo() {
		$('.ocrext-wrapper').css('opacity', 0);
		OCRTranslator.reset();
		// timeout to ensure that a render is done before initiating next capture cycle
		setTimeout(function () {
			_captureImageOntoCanvas().done(function () {
				_processOCRTranslate();
				_setZIndex();
			});
		}, 20);
	}

	/*
	 * Recapture button click handler
	 * Hands control back to the user to recapture the viewport
	 */
	function onOCRRecapture() {
		IS_CAPTURED = false;
		OCRTranslator.slideDown();
		// reset stuff
		OCRTranslator.reset();
		Mask.addToBody().show();
		//Mask.addToBody().hide();
		$('body').addClass('ocrext-ch');
	}

	/*
	 * Translate text from textarea
	 */
	function onRetranslate() {
		var $display = $.Deferred();

		$display
			.done(function (txt) {
				if (txt === 'no-translate') {
					$('.ocrext-ocr-message').addClass('ocrext-preserve-whitespace expanded');
					$('.ocrext-grid-translated').hide();
					$('.ocrext-ocr-translated').text("");
					$('.ocrext-ocr-retranslate').hide();
				} else {
					$('.ocrext-ocr-message').removeClass('ocrext-preserve-whitespace expanded');
					$('.ocrext-grid-translated').show();
					$('.ocrext-ocr-retranslate').show();
					$('.ocrext-ocr-translated')
						.text(txt)
						.show();
				}

				$('.ocrext-btn').removeClass('disabled');
				OCRTranslator.setStatus('success', chrome.i18n.getMessage('translationSuccessStatus'));
				OCRTranslator.enableContent();
			})
			.fail(function (err) {
				// All API failure handling is done here, the AJAX callbacks simply relay
				// necessary data to this callback
				$('.ocrext-btn').removeClass('disabled');
				OCRTranslator.setStatus('error', err.stat);
				$('.ocrext-ocr-translated').text('N/A');
				OCRTranslator.enableContent();
				//console.error('Visual Copy Exception', err);
			});

		var text = $(".ocrext-ocr-message").val();
		$.ajax({
			url: APPCONFIG.yandex_api_url,
			data: {
				key: APPCONFIG.yandex_api_key,
				lang: OPTIONS.visualCopyTranslateLang,
				text: text
			},
			timeout: APPCONFIG.yandex_timeout,
			type: 'GET',
			success: function (data) {
				if (data.code === 200) {
					$display.resolve(data.text);
				}
			},
			error: function (x, t) {
				var errData;
				try {
					errData = JSON.parse(x.responseText);
				} catch (e) {
					errData = {};
				}
				$display.reject({
					type: 'translate',
					stat: t === 'timeout' ? 'Translation request timed out' : 'An error occurred during translation',
					message: errData.message,
					details: null,
					code: errData.code
				});
			}
		});
	}

	/*
	 * Close button click handler. Also called on press of ESC
	 * Close the current session and communicate this to the bg page (main extension)
	 * Release any global state captured in between
	 */
	function onOCRClose(e) {
		e && e.stopPropagation();

		if (OCRTranslator.state === 'disabled') {
			return true;
		}
		$('header.ocrext-header').removeClass('minimized');
		$('.ocrext-wrapper').removeClass('ocrext-wrapper-minimized');
		OCRTranslator.disable();
		chrome.runtime.sendMessage({
			evt: 'capture-done'
		}, function ( /*resp*/ ) {

		});
        window.postMessage({ type: "FROM_PAGE", text: "ocrDisabled" }, "*");
	}


	/*
	 * @module: OCRTranslator
	 * The main translator module. Simple module pattern, no fancy constructors or factories
	 */
	var OCRTranslator = {
		/*
		 * Pseudo constructor
		 * init: load resources and bind runtime listener, once the $ready deferred 
		 * resolves, render HTML on 'enableselection' event
		 * Nothing gets rendered until the user presses the browserAction atleast 
		 * once within a tab. Only listeners get added and these simply bubble up
		 * (delegated to body)
		 */
		init: function () {
			// get config information
			var self = this;
			this._initializing = true;
			this._initialized = false;
			$ready = _bootStrapResources();


			// listen to runtime messages from other pages, mainly the background page
			chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
				if (sender.tab) {
					return true;
				}
				if (request.evt === 'isavailable') {
					if (self._initialized) {
						sendResponse({
							farewell: 'isavailable:OK'
						});
					} else {
						// if not yet initialized and body is still unavailable, reject
						if (!$('body').length) {
							sendResponse({
								farewell: 'isavailable:FAIL'
							});
						} else {
							$ready.done(function () {
								self._initialize();
								sendResponse({
									farewell: 'isavailable:OK'
								});
							});
						}
					}
					return true;
				}
				if (request.evt === 'enableselection') {
					// enable only if resources are loaded and available
					$ready.done(function () {
						OCRTranslator.enable();
					});
					// ACK back
					sendResponse({
						farewell: 'enableselection:OK'
					});
				}
			});
			$(document).ready(function () {
				if (!self._initialized && !self._initializing) {
					$ready.done(function () {
						self._initialize();
					});
				}
			});
			return this;
		},

		_initialize: function () {
			// kind of like using a lock
			this._initializing = false;
			this._initialized = true;
			ISPOSITIONED = ['absolute', 'relative', 'fixed'].indexOf($('body').css('position')) >= 0;
			this.initWidgets();
			this.bindEvents();
            // Listen for recapture events from other extensions
            window.addEventListener("message", function(event) {
              // We only accept messages from ourselves
              if (event.source != window)
                return;
            
              if (event.data.type && (event.data.type == "FROM_PAGE")) {
                  console.log("received ocr capture event: "+event.data.text);
                  if (event.data.text == 'ocrRequestStatus') {
		              if (OCRTranslator.state === 'disabled') {
                          window.postMessage({ type: "FROM_PAGE", text: "ocrDisabled" }, "*");
                      } else {
                          window.postMessage({ type: "FROM_PAGE", text: "ocrEnabled" }, "*");
                      }
                  } else if (event.data.text == 'ocrEnableCapture') {
					  OCRTranslator.enable();
                  } else if (event.data.text == 'capture') {
                      var reenable = false;
		              if (OCRTranslator.state === 'enabled') {
                          reenable = true; 
                          onOCRClose();
                      }
                      $('#aleksi_capture_mask').show();
                      $('#aleksi_capture_mask').on('mousedown', function(e) {
                          IS_CAPTURED = false;
                          onOCRMouseDown(e, function(evt) {
                              $('#aleksi_capture_mask').hide();
                              window.postMessage({ type: "FROM_PAGE", text: "captureComplete" }, "*");
                              if (reenable) {
                                  IS_CAPTURED = false;
					              OCRTranslator.enable();
                              }
                          }, function(evt) {
                              $('#aleksi_capture_mask').hide();
                              var imgSrc;
                              $('img').each(function() {
                                if (mouse_event_over_element(e, $(this))) {
                                  imgSrc = $(this).attr("src");
                                  return false;
                                }
                              });
                              window.postMessage({ type: "FROM_PAGE", text: "captureComplete", 'imgSrc': imgSrc }, "*");
                              if (reenable) {
                                  IS_CAPTURED = false;
					              OCRTranslator.enable();
                              }
                          });
                      });
                  }
                  if (event.data.text == 'ocrDisableCapture') {
                      onOCRClose();
                  }
              }
            }, false);
			// tell the background page that the tab is ready
			chrome.runtime.sendMessage({
				evt: 'ready'
			});
		},

		initWidgets: function () {
			$('body').append(HTMLSTRCOPY);
			$('.ocrext-title span').text(appName);
			if (!OPTIONS.visualCopyAutoTranslate) {
				$('.ocrext-ocr-message').addClass('ocrext-preserve-whitespace expanded');
				$('.ocrext-grid-translated').hide();
			}
            $('#ocrext-canOrig').appendTo('body');
			// set paragraph font
			_setLanguageOnUI();
			// set OCR font size
			_setOCRFontSize();
			// draw quick selection buttons
			_drawQuickSelectButtons();
			// upgrade buttons
			$('button.ocrext-btn').each(function (i, el) {
				componentHandler.upgradeElement(el);
			});
			// upgrade spinner
			//componentHandler.upgradeElement($('.ocrext-spinner').get(0));
		},

		/*
		 * Bind listeners for interactive elements exposed to user
		 * click - redo ocr, recapture, close, copy-to-clipboard
		 */
		bindEvents: function () {
			var $body = $('body');
			var self = this;
			$body
				.on('dblclick', '.ocrext-textoverlay-container', function () {
					if ($('#ocrext-can').parents('.ocrext-content').hasClass('ocrext-disabled')) {
						return true;
					}
					if (OPTIONS.visualCopyTextOverlay) {
						self.showOverlayTab();
					} else {
						window.alert('Please enable the "Show Text Overlay" option to view text overlays.');
					}
				})
				.on('dblclick', '#ocrext-can', function () {
					if ($(this).parents('.ocrext-content').hasClass('ocrext-disabled')) {
						return true;
					}
					if (OPTIONS.visualCopyTextOverlay) {
						self.showOverlayTab();
					} else {
						window.alert('Please enable the "Show Text Overlay" option to view text overlays.');
					}
				})
				.on('click', '.ocrext-ocr-recapture', onOCRRecapture)
				.on('click', '.ocrext-ocr-retranslate', onRetranslate)
				.on('click', '.ocrext-ocr-sendocr', onOCRRedo)
				.on('click', '.ocrext-closeToolbar-link', onOCRClose)
				.on('click', '.ocrext-ocr-copy', function () {
					/*Copy button click handler*/
					var message = $('.ocrext-ocr-message').val();
					var translation = $('.ocrext-ocr-translated').text();
					var text = message + translation;
					chrome.runtime.sendMessage({
						evt: 'copy',
						text: text
					});
				})
				.on('click', '.ocrext-ocr-quickselect', function () {
					var $el = $(this);
					/*if($el.hasClass('selected')){
					 return false;
					 }*/
					$el.siblings().removeClass('selected');
					$el.addClass('selected');
					setOptions({
						visualCopyOCRLang: $(this).attr('data-lang')
					}).done(function () {
						onOCRRedo();
					});
				})
				.on('click', 'header.ocrext-header', function () {
					/*click handler for header*/
					var $this = $(this);

					if ($this.hasClass('minimized')) {
						$('.ocrext-wrapper').removeClass('ocrext-wrapper-minimized');
						$this.removeClass('minimized');
					} else {
						$('.ocrext-wrapper').addClass('ocrext-wrapper-minimized');
						$this.addClass('minimized');
					}
				})
				.on('click', 'a.ocrext-settings-link', function (e) {
					/*Settings  (gear icon) click handler*/
					e.stopPropagation();
					chrome.runtime.sendMessage({
						evt: 'open-settings'
					});
				});

			/*ESC handler. */
			$(document).on('keyup', function (e) {
				if (e.keyCode === 27) {
					onOCRClose();
				}
			});
			return this;
		},

		/*
		 * Enable selection within the viewport. Render the HTML if it does not already exist
		 * Why render again? Some rogue pages might empty the entire HTML content for some reason
		 */
		enable: function () {
			var $body = $('body');
			/* check again before enabling selection. If the page has decided to empty body and
			 * rerender, the extension code will also be lost
			 */
			if (!$body.find('.ocrext-wrapper').length) {
				$body.append(HTMLSTRCOPY);
			}
			$body.addClass('ocrext-overlay ocrext-ch')
				.find('.ocrext-wrapper')
				.hide();
			$('.ocrext-title span').text(appName);
			OCRTranslator.reset();
			// show mask
			//Mask.addToBody().hide();
		    Mask.addToBody().show();
			// instantiate overlay
			//this.textOverlay = TextOverlay();
			//$body.on('mousedown', onOCRMouseDown);
            $('.ocrext-mask').on('mousedown', function(e) {
                onOCRMouseDown(e, _processOCRTranslate, function() {});
            });
            //$('.ocrext-mask').forwardMouseEvents();
			OCRTranslator.state = 'enabled';
            window.postMessage({ type: "FROM_PAGE", text: "ocrEnabled" }, "*");
			return this;
		},

		/*
		 * Hide the widget. Does not destroy/recreate, the widget size isn't big enough 
		 * to adversely impact page weight
		 */
		disable: function () {
			var $body = $('body');
			$body.removeClass('ocrext-overlay ocrext-ch')
				.find('.ocrext-wrapper')
				.hide();
			$body.off('mousedown', onOCRMouseDown);
			OCRTranslator.state = 'disabled';
			Mask.remove();
			OCRTranslator.reset();
			IS_CAPTURED = false;
			return this;
		},

		// reset anything that requires resetting
		reset: function () {
			$('.ocrext-status').text('').removeClass('ocrext-success ocrext-error ocrext-progress');
			$('.ocrext-result').text('N/A');
			$('.ocrext-result').attr({
				title: ''
			});
			if (this.textOverlay) {
				this.resetOverlay();
			}

			return this;
		},

		// spinner logic
		enableContent: function () {
			$('.ocrext-spinner').removeClass('is-active');
			$('.ocrext-content').removeClass('ocrext-disabled');
			$('.ocrext-btn-container .ocrext-btn').removeClass('disabled').removeAttr('disabled');
			$('.ocrext-quickselect-btn-container .ocrext-btn').removeClass('disabled').removeAttr('disabled');
			return this;
		},

		// spinner logic
		disableContent: function () {
			$('.ocrext-spinner').addClass('is-active');
			$('.ocrext-content').addClass('ocrext-disabled');
			$('.ocrext-btn-container .ocrext-btn').addClass('disabled').attr('disabled', 'disabled');
			$('.ocrext-quickselect-btn-container .ocrext-btn').addClass('disabled').attr('disabled', 'disabled');
			return this;
		},

		// Utility to set the status - progress, error and success are supported
		// pass noAutoClose as true if the status message must be persisted beyond 10s
		setStatus: function (status, txt, noAutoClose) {
			if (status === 'error') {
				$('.ocrext-content').addClass('ocrext-error');
			} else {
				$('.ocrext-content').removeClass('ocrext-error');
			}
			$('.ocrext-status')
				.removeClass('ocrext-success ocrext-error ocrext-progress')
				.addClass(status === 'error' ? 'ocrext-error' :
					(status === 'success' ? 'ocrext-success' : 'ocrext-progress'))
				.text(txt);
			if (!noAutoClose) {
				setTimeout(function () {
					$('.ocrext-status').removeClass('ocrext-success ocrext-error ocrext-progress');
				}, 10000);
			}
		},

		slideDown: function () {
			var $dialog = $('.ocrext-wrapper');
			$dialog.css({
				bottom: -$dialog.height()
			});
		},

		slideUp: function () {
			$('.ocrext-wrapper').css('bottom', WIDGETBOTTOM);
		},

		setOverlayInformation: function (overlay, imgDataURI) {
			this._overlay = overlay;
			// this._imgDataURI = imgDataURI;
		},

		resetOverlayInformation: function () {
			this._overlay = null;
			// this._imgDataURI = null;
		},

		showOverlay: function () {
			var $canvas = $('#ocrext-can');
			var $canvasOrig = $('#ocrext-canOrig');
			this.textOverlay
				.setOverlayInformation(this._overlay, $canvas.width(), $canvas.height(), null, $canvas.width() / $canvasOrig.width())
				.show();
		},

		showOverlayTab: function () {
			var $canvas = $('#ocrext-can');
			var $canvasOrig = $('#ocrext-canOrig');
			chrome.runtime.sendMessage({
				evt: 'show-overlay-tab',
				overlayInfo: this._overlay,
				imgDataURI: $canvas.get(0).toDataURL(),
				canWidth: $canvas.width(),
				canHeight: $canvas.height(),
				zoom: $canvas.width() / $canvasOrig.width()
			}, function () {
				/* done */
			});
		},

		hideOverlay: function () {
			this.textOverlay.hide();
		},

		resetOverlay: function () {
			this.textOverlay.reset().hide();
		}
	};

	getOptions().done(function () {
		$(document.body).on("keydown", function (e) {
			if (e.ctrlKey && e.shiftKey) {
				if (e.keyCode === OPTIONS.openGrabbingScreenHotkey) {
					chrome.runtime.sendMessage({
						evt: 'activate'
					});
					e.stopPropagation();
					e.preventDefault();
					return false;
				} else if (e.keyCode === OPTIONS.closePanelHotkey) {
					$(".ocrext-closeToolbar-link").click();
					e.stopPropagation();
					e.preventDefault();
					return false;
				} else if (e.keyCode === OPTIONS.copyTextHotkey) {
					$(".ocrext-ocr-copy").click();
					e.stopPropagation();
					e.preventDefault();
					return false;
				}
			}
		});
	});

	OCRTranslator.init();
}(jQuery));
